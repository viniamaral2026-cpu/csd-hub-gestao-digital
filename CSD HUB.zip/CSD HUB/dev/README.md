﻿# README.md
# Área do Desenvolvedor

Espaço dedicado a desenvolvedores e parceiros.

Inclui:
- SDK
- API pública
- Webhooks
- Exemplos
- Documentação técnica
