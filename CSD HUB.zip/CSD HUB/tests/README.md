﻿# README.md
# Testes

Testes automatizados do sistema.

Inclui:
- Unitários
- Integração
- End-to-end
