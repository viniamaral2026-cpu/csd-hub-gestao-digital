﻿# README.md
# Documentação

Documentação oficial do sistema.

Inclui:
- Arquitetura
- Requisitos
- Jurídico
- Financeiro
- API
