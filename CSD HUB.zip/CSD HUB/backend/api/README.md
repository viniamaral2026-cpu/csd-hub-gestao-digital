﻿# API

Camada de exposição das funcionalidades do sistema.

Responsável por:
- Endpoints REST/GraphQL
- Autenticação e autorização
- Versionamento de API
- Integração com frontend, mobile e parceiros
