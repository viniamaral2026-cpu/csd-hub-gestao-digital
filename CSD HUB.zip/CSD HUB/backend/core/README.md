﻿# README.md
# Core

Camada central de domínio do sistema.

Contém:
- Entidades base
- Casos de uso
- Regras de negócio transversais
- Lógica independente de framework
