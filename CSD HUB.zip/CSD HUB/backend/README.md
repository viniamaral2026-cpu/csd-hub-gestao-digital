﻿# README.md
# Backend – CSD HUB

Núcleo do sistema CSD HUB. Responsável por regras de negócio, APIs, segurança,
processamento financeiro, jurídico e integrações externas.

Arquitetura orientada a módulos, preparada para SaaS, multi-tenant e API pública.
