﻿# README.md
# Segurança

Responsável por:
- Autenticação (JWT, OAuth, Gov.br)
- Controle de acesso (RBAC)
- Criptografia
- Auditoria e logs sensíveis
