﻿# README.md
# Configurações

Configurações globais do sistema:
- Variáveis de ambiente
- Configuração de banco de dados
- Providers externos
- Feature flags
