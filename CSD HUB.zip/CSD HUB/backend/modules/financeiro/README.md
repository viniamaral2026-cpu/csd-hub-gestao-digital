﻿# README.md
# Módulo Financeiro

Gerencia toda a lógica financeira do sistema.

Inclui:
- Contas
- Lançamentos
- Cobranças
- Impostos
- Relatórios financeiros

Base para faturamento, SaaS billing e integrações bancárias.
