﻿# README.md
# Módulos de Negócio

Cada módulo representa um domínio funcional isolado do sistema,
seguindo princípios de DDD e baixo acoplamento.
