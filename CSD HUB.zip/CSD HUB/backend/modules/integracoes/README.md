﻿# README.md
# Integrações

Integrações com serviços externos e APIs de terceiros.

Cada subpasta representa um provider isolado.
