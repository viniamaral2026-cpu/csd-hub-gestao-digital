﻿# README.md
# Assinaturas

Gerenciamento de assinaturas digitais e planos recorrentes.

Suporte a:
- SaaS billing
- Assinatura Gov.br
- Validação jurídica
