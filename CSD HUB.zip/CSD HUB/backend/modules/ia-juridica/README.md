﻿# README.md
# Módulo IA Jurídica

Responsável por automações jurídicas e suporte inteligente.

Inclui:
- Análise de contratos
- Pareceres assistidos por IA
- Avaliação de riscos
- Compliance legal
