﻿# README.md
# Módulo de Contratos

Geração, versionamento e assinatura de contratos digitais.

Integra:
- Assinatura eletrônica
- Templates jurídicos
- Histórico legal
