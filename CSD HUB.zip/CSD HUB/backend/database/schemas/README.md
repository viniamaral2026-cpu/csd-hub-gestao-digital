﻿# README.md
# Schemas

Definição formal das estruturas de dados,
validações e contratos entre aplicação e banco.
