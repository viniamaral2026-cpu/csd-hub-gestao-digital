﻿# README.md
# Migrations

Controle de versão do banco de dados.
Cada alteração estrutural deve passar por migration.
