﻿# README.md
# Auditoria

Registros imutáveis de eventos críticos:
- Financeiros
- Jurídicos
- Acesso e alterações sensíveis
