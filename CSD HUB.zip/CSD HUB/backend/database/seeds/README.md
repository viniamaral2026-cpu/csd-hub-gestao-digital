﻿# README.md
# Seeds

Dados iniciais para desenvolvimento, testes e ambientes controlados.
