﻿# README.md
# Infraestrutura

Configurações de infraestrutura e DevOps.

Inclui:
- Docker
- Kubernetes
- CI/CD
- Monitoramento
- Logs
