﻿# README.md
# Frontend

Interface do usuário do CSD HUB.

Separado por contextos:
- Web pública
- Admin
- Painéis especializados
