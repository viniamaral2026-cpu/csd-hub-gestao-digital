﻿# README.md
# Scripts

Scripts utilitários para:
- Automação
- Deploy
- Manutenção
